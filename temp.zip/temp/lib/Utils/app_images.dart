class AppImages {
  static String logo = "assets/images/logo.png";
  static String appbarImg = "assets/images/appbar image.png";
  static String google = "assets/images/google.png";
  static String linkedin = "assets/images/linkedin.png";
  static String facbook = "assets/images/facebook.png";
  static String profile = "assets/images/profile.png";

  static String appLogo = 'assets/images/appLogo.png';
  static String profileImg = 'assets/images/profile.png';
  static String wifiImg = 'assets/images/wifi.png';
  static String packageLogo = 'assets/images/logo.png';
  static String orangeIcon = 'assets/images/orangeicon.png';
  static String greenIcon = 'assets/images/greenicon.png';
  static String redIcon = 'assets/images/redicon.png';
  static String batteryFull = 'assets/images/battery90.png';
  static String batteryLow = 'assets/images/battery20.png';
  static String diamondImg = 'assets/images/diamond.png';
  static String checkMark = 'assets/images/checkmark.png';

  static String box = "assets/images/box.png";
  static String alram = 'assets/images/alram.png';
  static String speaker = 'assets/images/speaker.png';
  static String share1 = 'assets/images/share.png';
  static String share2 = 'assets/images/shapre2.png';
  static String vector = 'assets/images/vector.png';
  static String dppp = 'assets/images/dppp.png';
  static String hose = 'assets/images/hose.png';
  static String guard = "assets/images/guard.png";

  String appBar = 'assets/tab_bar.png';
  String menu = 'assets/menu.png';
  String bantery = 'assets/bantery.png';
  String image3 = 'assets/image 3.png';
  String wifi = 'assets/wifi 1.png';
  String pen = 'assets/pen.png';
  String bin = 'assets/bin.png';
  String pin = 'assets/image 13.png';
}
